//  Actividad Integradora 2
//
//  Alejandro Díaz Villagómez | A01276769
//  Emiliano Saucedo Arriola  | A01659258
//
//  Fecha: 17/11/2022

#include "Point.hpp"

//Constructor
//Complejidad: O(1)
Point::Point(float _x, float _y){
    x = _x;
    y = _y;
}
