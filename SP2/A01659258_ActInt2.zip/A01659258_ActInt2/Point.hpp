//  Actividad Integradora 2
//
//  Alejandro Díaz Villagómez | A01276769
//  Emiliano Saucedo Arriola  | A01659258
//
//  Fecha: 17/11/2022

#ifndef Point_hpp
#define Point_hpp

#include <stdio.h>

#pragma once
#include <stdio.h>
#include <vector>

using namespace std;

class Point{
public:
    float x;
    float y;
    Point(float _x, float _y);
};

#endif /* Point_hpp */
